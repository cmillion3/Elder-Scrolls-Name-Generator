This is the first version of The Elder Scrolls Name generator finalized on July 8th 2023

Names are gathered from the arena and daggerfall games, I plan to add an option for pre-existing NPC names across all games soon, as well as surnames and fleshing out the GUI

For now, this is a working program and all the base logic is functional. Just choose one of the two genders, and then choose a race and the generate button will do it's thing. 

Quick note about Redguards, since they have the option of adding an extra suffix, the number of redguard names are exponentially higher than the rest.

Updates:
July 13th, 2023 - Added pictures, rewrote code for grid placement instead of pack placement. All photos are screenshots taken from The Elder Scrolls: Skyrim created by Bethesda Softworks 

Github: https://github.com/cmillion3 